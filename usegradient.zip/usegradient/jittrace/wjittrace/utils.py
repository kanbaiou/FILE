import torch
import torch.nn as nn
from copy import deepcopy
from wjittrace import * 
from utils_2 import *


USEFUL_NODES =\
    ['aten::constant_pad_nd','aten::add','aten::cat','aten::view','aten::addmm','aten::_convolution','aten::batch_norm']

SHARING_NODES = ['aten::add','aten::cat']

def expand_backward(backward_object):

     u = backward_object
     while isinstance(u,tuple):
         u = u[0]
   
     return u


def is_leaf(backward_object):
      True_mark = True
      if backward_object !=None:
            for  u in backward_object.next_functions:
                if  not hasattr(u[0],'variable'):
                    True_mark = False

      return True_mark
   
def get_next_father_node(backward_object):
      father_node_list =[]
      for i in backward_object.next_functions:
          u=expand_backward(i)
          if not is_leaf(u):
                  father_node_list.append(u)

      return father_node_list 


def  is_terminated(input_list):
    mark_terminated = True
    for i in input_list:
        if i!=[]:
            mark_terminated = False

    return  mark_terminated

def index_node(test_str,i):
      return test_str + str(i)
       
def generate_network_graph(start_point):
       network_graph ={}
       node_list =[start_point]
       all_node= []

       while not is_terminated(node_list):  ## if all the route reach the end leaf , end  terminate the expand
          expand_list =[]
          for node  in node_list:
                 if node != [] and node not in all_node:## if reach the end stop the expand
                    all_node.append(node) 
                    child_node_list=get_next_father_node(node)    ###  expand the next level 
                    network_graph[node] = [n for n in child_node_list ]    ### add the node to graph ()
                    if child_node_list!=[]:
                        expand_list+=child_node_list
                    else:   
                        expand_list.append(child_node_list) ### append all next level node to the list
                        end_node = node
          node_list = expand_list
      
       return  network_graph,end_node



####  graph_related
def searchGraph(graph, start, end):					
	results = []                
	generateallPath(graph, [start], end, results)			
	results.sort(key=lambda x:len(x))					
	return results




def generateallPath(graph, path, end, results):		
	state = path[-1]   ##initial  state is the start point
	if state == end:
		results.append(path)
	else:
		for arc in graph[state]:  ### all jointed node of the start node
			if arc not in path:  ###   if not reach the end , expand the start node     
				generateallPath(graph, path + [arc], end, results)

    ### analyse the  recursive process
      ###  from current state to next state  
            ### current state:     all the node  and the end state
            ### next state:         for all jointed next node , if not in the graph , append it to the path ,    

def generateonePath(graph, path, end, results,n):		
    state = path[-1]
    if len(results) ==n:
        
        return  
    if state == end:
	    results.append(path)

    else:
       for arc in graph[state]:
	       if arc not in path:
	           generateonePath(graph, path + [arc], end, results,n)

def search_N_route(graph,start,end,n):
    results=[]
    generateonePath(graph,[start],end,results,n)
    results.sort(key = lambda x:len(x))

    return results


    
def expand_graph(graph): 
    ## give the 
    
    for k in graph.keys():
        for jointed_node in graph[k]:
            if    k not in graph[jointed_node]:
                graph[jointed_node].append(k)


def reverse_graph(graph,len_list):
   
   key_list = list(graph.keys()) 
   assert  len(key_list) ==  len(len_list)
   for i in range(len(key_list)):
       del  graph[key_list[i]][0:len_list[i]]  ## delete the original node only remain reversed node 
  
   

def  shrink_graph_back(graph,len_list):
     #### here the len_list is  diff between new_len_list and old_len_list
     key_list = list(graph.keys())
     assert len(key_list) == len(len_list)
     for i in range(len(key_list)):
         del graph[key_list[i]][-1:(-1-len_list[i]):-1]




def get_backward_name(backward_object):
    str_list = str(backward_object).split(' ')
    backward_name = str_list[0]
    backward_name=backward_name.split('<')[1]
    return backward_name





def create_module_dic(graph):

    module_dic = {}
    for k in graph.keys():
        if  'CONV' in str(k).upper():
            module_dic[k] = from_backward_to_module('conv',k)
        elif  'BATCHNORM'  in str(k).upper():
            module_dic[k] = from_backward_to_module('batchnorm',k)
        elif 'ADD' in str(k).upper():
            module_dic[k] = from_backward_to_module('add',k)
        elif   'CAT' in str(k).upper():
            module_dic[k] = from_backward_to_module('cat',k)
        elif   'AVGPOOL' in str(k).upper():
            module_dic[k] = from_backward_to_module('avgpool',k)
        elif  'MAXPOOL' in  str(k).upper():
            module_dic[k] = from_backward_to_module('max_pool',k)
        elif 'ADMM' in str(k).upper():
            module_dic[k] = from_backward_to_module('linear',k)
        elif 'RELU' in  str(k).upper():
           module_dic[k] = from_backward_to_module('relu',k)
        elif 'VIEW' in str(k).upper():
            module_dic[k] = from_backward_to_module('view',k)
    
    return module_dic
     


def from_backward_to_module(optype, backward_object):
    pass
    return optype




def dataflow_for_branch(node_branch,conv_list,bn_list,branch_channel_list,start_node,initial_depth,Jgraph):
      
      ###  TODO in dataflow_for_branch
                        ###  input initial_depth 
                        ###  if  meet cetain nodes:
                        ###        if  is_padding-node or view node,
                        ###                get pading or view 's operation details 
                        ###                update dataflow's depth
                        ###        if  is conv-node or  BN node,fc node
                        #                  change conv or bn laye's input channel
                        #                  update dataflow's depth
                        ###                save node to conv_list or bn_list
                        ##             
      branch_conv_list,branch_bn_list = [],[]
      output_depth = initial_depth
      for  j in node_branch[start_node:-1]:
          if j.kind() =='aten::_convlution' :
              print('find_conv')
              ### TODO
              input_channel = output_depth
              Jnode = JITNode(j,Jgraph)
              nnmodule_ob = Jnode.pyobject
              if is_pruning_target(j,Jgraph):
                  output_channel = get_pruning_channel(Jnode,Jgraph)

              else:
                  output_channel = nnmodule_ob.weight.data.shape[0]
              set_pruning_channel(j,Jgraph,input_channel= input_channel,output_channel=output_channel)
              output_depth = output_channel   ###NOTE output depth shoulde be kept updated
              branch_conv_list.append(j)

                  
          elif j.kind() == 'aten::batch_norm':
              print('find_BN')          
              ###### TODO
              output_channel = output_depth     ###dataflow 'S depth will not be changed        
              if is_pruning_target(j,Jgraph):     
                  assert get_pruning_channel(j,Jgraph)==output_depth
              Jnode = JITNode(j,Jgraph)
              nnmodule_ob = Jnode.pyobject
              set_pruning_channel(j,Jgraph,output_channel=output_channel)
              branch_bn_list.append(j)

          elif j.kind()=='aten::constant_pad_nd':
              print('find_padding')
               ## TODO
              input_shape = JITNode(j,Jgraph).inputs[0].shape
              output_shape = JITNode(j,Jgraph).outputs[0].shape
              added_channel = output_shape[1] - input_shape[1]
              output_depth+=added_channel 
          elif j.kind() =='aten::view':
              print('find_view')
              input_shape = JITNode(j,Jgraph).inputs[0].shape
              output_shape = JITNode(j,Jgraph).inputs[0].shape
              output_depth = get_newchannel_view(input_shape,output_shape,output_depth)  
          elif j.kind() =='aten:addmm':
               print('find_linear')
               ## TODO
               Jnode = JITNode(j,Jgraph)
               nnmodule_ob = Jnode.pyobject
               new_linear = from_linear_to_linear(nnmodule_ob,input_features=output_depth)
               net = Jgraph.pymodel
               from_old_to_new(net,nnmodule_ob,new_linear)
        
      branch_channel_list.append(output_depth)   ###  this branch's dataflow 's final depth 
      conv_list.append(branch_conv_list)         ###   all conv node in this list (raw_jitnode)  
      bn_list.append(branch_bn_list)            ###   all bn node on this list  (raw_jitnode)    


def get_next_useful_node(JITnode,next_useful_node):
    JITnode_input = JITnode.inputs
    for ip in JITnode_input:
        if ip.producer.operationname in USEFUL_NODES or ip== []:   ### exit of recursive   
               if ip.producer.operationname in  USEFUL_NODES:
                    next_useful_node.append(ip.producer)                 
        else:
                get_next_useful_node(ip.producer,next_useful_node)


def  non_duplicate(list_ob):   # NOTE this can only keep out from one node can reach more than one same node's situation if the node is not same , the  
        str_list = [str(i) for i in list_ob]
        for l in list_ob:
                if str_list.count(str(l)) >=2:
                        ind =  list_ob.index(l)
                        del list_ob[ind]
                        del  str_list[ind]



#### NOTE the following function should be defined base on the 

def is_pruning_target(jit_rawnode,Jgraph):
   ##  jit_rawnode get from jit.trace().graph  
   Jnode = JITNode(jit_rawnode,Jgraph)
   nnmodule_ob = Jnode.pyobject
   
   
   
   weight_ = deepcopy(nnmodule_ob.weight.data)
   
   if isinstance(nnmodule_ob,nn.BatchNorm2d):
       weight_[0] =  weight_[0]*0
   elif isinstance(nnmodule_ob,nn.Conv2d):
       weight_[0][0][0][0] = weight_[0][0][0][0]*0

   if weight_.mean().item() ==0:
       return True
   else:
       return False


def get_pruning_channel(jit_rawnode,Jgraph):
    
   
   Jnode = JITNode(jit_rawnode,Jgraph)
   nnmodule_ob =  Jnode.pyobject
   
   if  isinstance(nnmodule_ob,nn.BatchNorm2d):
       output_channel = int(nnmodule_ob.weight.data[0]*100)
   
   elif isinstance(nnmodule_ob,nn.Conv2d):
       output_channel = int(nnmodule_ob.weight.data[0][0][0][0]*100)

   return output_channel    



def  set_pruning_channel(jit_rawnode,JGraph,input_channel=None,output_channel=None):
    """ 
        replace basic module in baseline_model
        jitgraph : JITGraph type object
        if nn_module is pruning_target
        get the correct channel, setting the correct new basic module
        get original pyobject , replace it with the new basic module 
        
    """
    net = JGraph.pymodel
    JNode = JITNode(jit_rawnode,JGraph)
    nnmodule_ob = JNode.pyobject
    if output_channel == None:
       new_channel = get_pruning_channel(jit_rawnode,JGraph)
    else:
       new_channel = output_channel
    
    if input_channel == None:

       if isinstance(nnmodule_ob,nn.BatchNorm2d):
          new_module = nn.BatchNorm2d(new_channel)
       elif isinstance(nnmodule_ob,nn.Conv2d):
          new_module = from_conv_to_conv(nnmodule_ob,output_channel=new_channel)
    ##   replace old module with new module
    else:
       new_module = from_conv_to_conv(nnmodule_ob,input_channel= input_channel,output_channel=new_channel)
    
    from_old_to_new(net,nnmodule_ob,new_module)





def get_newchannel_view(input_shape,output_shape,input_channel):
    new_output=1 
    for i in range(len(input_shape)):
        if i == 1:
            new_output*=input_channel
        else:
            new_output*=input_shape[i]
      
    new_channel= new_output

    for i in range(len(output_shape)):
        if i==1:
            new_channel/=1
        else:
            new_channel/=output_shape[i] 
    
    new_channel = int(new_channel)
    return new_channel