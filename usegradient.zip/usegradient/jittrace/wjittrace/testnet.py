import torch
import torch.nn as nn
import torch.nn.functional as F 



class TestNet(nn.Module):

    def __init__(self):
        super(TestNet, self).__init__()
        self.conv1 = nn.Conv2d(3, 16, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(16)
        self.conv_b1 = nn.Conv2d(16,32,kernel_size=3,stride=1,padding=1,bias=False)
        self.bn_b1  =nn.BatchNorm2d(32)
        self.conv_b2 = nn.Conv2d(16,16,kernel_size=3,stride=1,padding=1,bias=False)
        self.bn_b2 = nn.BatchNorm2d(16)
        self.linear = nn.Linear(768,10)
    def forward(self, x):
        out = self.bn1(self.conv1(x))
        out_b1 =  self.bn_b1(self.conv_b1(out))
        out_b1 = out_b1.view(out_b1.size(0),-1,8,8)
        out_b2 =  self.bn_b2(self.conv_b2(out))
        out_b2 = out_b2.view(out_b2.size(0),-1,8,8)
        out  = torch.cat([out_b1,out_b2],1)
        pad_1 = (2,2,2,2)
        pad_2 =(6,6,6,6)
        out_1 = F.pad(out,pad_1)
        out_2 = F.pad(out,pad_2)
        out_1 = F.avg_pool2d(out_1,12)#.view(5,-1)
        out_2=  F.avg_pool2d(out_2,20)
        out_1 = out_1.view(out_1.shape[0],-1)
        out_2 = out_2.view(out_2.shape[0],-1)
        out = out_1+out_2
        out =  self.linear(out)

        return out