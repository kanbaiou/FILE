algo:
1. from start point ( end_point ), generate graph which contains all the father-nodes

  ~~2. search route from end to start(not searching all the route , only search two route to find the sharing node)~~

the above idea is not  aviable in a large graph

   so find the sharing node as the following step
a. recording lengh info
   for k ,v in graph.items():
        len_list.append(len(v))

b.  expand the graph

       expand_graph(graph)


c.   find the sharing node in expand_graph 
       if one node connect with more than 2 other nodes 
       sharing_node.append(node)

d.  shrink the graph to the reverse_graph

     for every node in the expand_graph:
         del expand_graph[node][0:i]   i is the corresponding  number in the len_list
        


      

2. define the new network module

     

        define a module_list: 
        
        check  all nodes in network_graph.keys() 
               todo here 
                   from backward object name :
                      if is conv or bn or linear or other holding-weight module :
                             define the same type module ,get channel information from  .next_functions.variable  (which's weight should contains the correct info)
                             defined another dictionary
                             which's key is all the node in the network graph
                             which's value is the defined basic module (for the following node do the same thing)
                      elif  relu , maxpool etc

                             define the same type module
                     elif add concat padding....etc
                             using original defined module (while add and concat will take two input)

          in the forward parts

                 for every  node pair
                 search the routes between them(one or two)
                 
                 using the self.dic to define the forward() process and output of the pair's small unit


