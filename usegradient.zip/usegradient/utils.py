import torch
import torch.nn as nn
from copy import deepcopy



def expand_backward(backward_object):

     u = backward_object
     while isinstance(u,tuple):
         u = u[0]
   
     return u


def is_leaf(backward_object):
      True_mark = True
      if backward_object !=None:
            for  u in backward_object.next_functions:
                if  not hasattr(u[0],'variable'):
                    True_mark = False

      return True_mark
   
def get_next_father_node(backward_object):
      father_node_list =[]
      for i in backward_object.next_functions:
          u=expand_backward(i)
          if not is_leaf(u):
                  father_node_list.append(u)

      return father_node_list 


def  is_terminated(input_list):
    mark_terminated = True
    for i in input_list:
        if i!=[]:
            mark_terminated = False

    return  mark_terminated

def index_node(test_str,i):
      return test_str + str(i)
       
def generate_network_graph(start_point):
       network_graph ={}
       node_list =[start_point]
       all_node= []

       while not is_terminated(node_list):  ## if all the route reach the end leaf , end  terminate the expand
          expand_list =[]
          for node  in node_list:
                 if node != [] and node not in all_node:## if reach the end stop the expand
                    all_node.append(node) 
                    child_node_list=get_next_father_node(node)    ###  expand the next level 
                    print(child_node_list)
                    network_graph[node] = [n for n in child_node_list ]    ### add the node to graph ()
                    if child_node_list!=[]:
                        expand_list+=child_node_list
                    else:   
                        expand_list.append(child_node_list) ### append all next level node to the list
                        end_node = node
          node_list = expand_list
      
       return  network_graph,end_node



####  graph_related
def searchGraph(graph, start, end):					
	results = []                
	generateallPath(graph, [start], end, results)			
	results.sort(key=lambda x:len(x))					
	return results




def generateallPath(graph, path, end, results):		
	state = path[-1]   ##initial  state is the start point
	if state == end:
		results.append(path)
	else:
		for arc in graph[state]:  ### all jointed node of the start node
			if arc not in path:  ###   if not reach the end , expand the start node     
				generateallPath(graph, path + [arc], end, results)

    ### analyse the  recursive process
      ###  from current state to next state  
            ### current state:     all the node  and the end state
            ### next state:         for all jointed next node , if not in the graph , append it to the path ,    

def generateonePath(graph, path, end, results,n):		
    state = path[-1]
    if len(results) ==n:
        
        return  
    if state == end:
	    results.append(path)

    else:
       for arc in graph[state]:
	       if arc not in path:
	           generateonePath(graph, path + [arc], end, results,n)

def search_N_route(graph,start,end,n):
    results=[]
    generateonePath(graph,[start],end,results,n)
    results.sort(key = lambda x:len(x))

    return results


    
def expand_graph(graph): 
    ## give the 
    
    for k in graph.keys():
        for jointed_node in graph[k]:
            if    k not in graph[jointed_node]:
                graph[jointed_node].append(k)


def reverse_graph(graph,len_list):
   
   key_list = list(graph.keys()) 
   assert  len(key_list) ==  len(len_list)
   for i in range(len(key_list)):
       del  graph[key_list[i]][0:len_list[i]]  ## delete the original node only remain reversed node 
  
   

def  shrink_graph_back(graph,len_list):
     #### here the len_list is  diff between new_len_list and old_len_list
     key_list = list(graph.keys())
     assert len(key_list) == len(len_list)
     for i in range(len(key_list)):
         del graph[key_list[i]][-1:(-1-len_list[i]):-1]




def get_backward_name(backward_object):
    str_list = str(backward_object).split(' ')
    backward_name = str_list[0]
    backward_name=backward_name.split('<')[1]
    return backward_name





def   create_module_dic(graph):

    module_dic = {}
    for k in graph.keys():
        if  'CONV' in str(k).upper():
            module_dic[k] = from_backward_to_module('conv',k)
        elif  'BATCHNORM'  in str(k).upper():
            module_dic[k] = from_backward_to_module('batchnorm',k)
        elif 'ADD' in str(k).upper():
            module_dic[k] = from_backward_to_module('add',k)
        elif   'CAT' in str(k).upper():
            module_dic[k] = from_backward_to_module('cat',k)
        elif   'AVGPOOL' in str(k).upper():
            module_dic[k] = from_backward_to_module('avgpool',k)
        elif  'MAXPOOL' in  str(k).upper():
            module_dic[k] = from_backward_to_module('max_pool',k)
        elif 'ADMM' in str(k).upper():
            module_dic[k] = from_backward_to_module('linear',k)
        elif 'RELU' in  str(k).upper():
           module_dic[k] = from_backward_to_module('relu',k)
        elif 'VIEW' in str(k).upper():
            module_dic[k] = from_backward_to_module('view',k)
    
    return module_dic
     


USEFUL_NODES =\
    ['aten::constant_pad_nd','aten::add','aten::cat','aten::view','aten::addmm','aten::_convolution','aten::batch_norm']

SHARING_NODES = ['aten::add','aten::cat']

def from_backward_to_module(optype, backward_object):
    pass
    return optype


def dataflow_for_branch(node_branch,conv_list,bn_list,branch_channel_list,start_node,initial_depth):
      branch_conv_list,branch_bn_list = [],[]
      output_depth =  initial_depth
      for  j in node_branch[start_node:-1]:
          if j.kind() =='aten::_convlution' :
              print('find_conv')
              ### TODO
          elif j.kind() =='aten::batch_norm':
              print('find_BN')
              ##   TODO
          elif j.kind()=='aten::constant_pad_nd':
               print('find_padding')
               ## TODO
          elif j.kind() =='aten::view':
               print('find_view')
               ## TODO
          elif j.kind() =='aten:addmm':
               print('find_linear')
               ## TODO
          branch_bn_list.append(output_depth)
          conv_list.append(branch_conv_list)
          bn_list.append(branch_bn_list)    
                