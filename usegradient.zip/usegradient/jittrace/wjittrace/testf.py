def get_newchannel_view(input_shape,output_shape,input_channel):
    new_output=1 
    for i in range(len(input_shape)):
        if i == 1:
            new_output*=input_channel
        else:
            new_output*=input_shape[i]
      
    new_channel= new_output

    for i in range(len(output_shape)):
        if i==1:
            new_channel/=1
        else:
            new_channel/=output_shape[i] 
    
    return new_channel