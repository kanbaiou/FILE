import torch
from torch.autograd import Variable


def get_graph(var, params=None):
    """ Produces Graphviz representation of PyTorch autograd graph.
    Blue nodes are the Variables that require grad, orange are Tensors
    saved for backward in torch.autograd.Function
    Args:
        var: output Variable
        params: dict of (name, Variable) to add names to node that
            require grad (TODO: make optional)
    """
    reversed_graph =[]
    if params is not None:
        assert all(isinstance(p, Variable) for p in params.values())
        param_map = {id(v): k for k, v in params.items()}

    seen = set()

    def size_to_str(size):
        return '(' + (', ').join(['%d' % v for v in size]) + ')'

    output_nodes = (var.grad_fn,) if not isinstance(var, tuple) else tuple(v.grad_fn for v in var)

    def add_nodes(var):

        if var not in seen:
            if torch.is_tensor(var):
                # note: this used to show .saved_tensors in pytorch0.2, but stopped
                # working as it was moved to ATen and Variable-Tensor merged
                reversed_graph.append((type(var).__name__,size_to_str(var.variable.size())))
            elif hasattr(var, 'variable'):
                reversed_graph.append((type(var).__name__,size_to_str(var.variable.size())))
                ### append module and its size
            elif var in output_nodes:
                reversed_graph.append(type(var).__name__)
            else:
                reversed_graph.append(type(var).__name__)
            seen.add(var)
            if hasattr(var, 'next_functions'):
               
                for u in var.next_functions:
                    if u[0] is not None:
                        
                        add_nodes(u[0])
            if hasattr(var, 'saved_tensors'):
       
                for t in var.saved_tensors:
                   
                    add_nodes(t)

    # handle multiple outputs
    if isinstance(var, tuple):
        for v in var:
            add_nodes(v.grad_fn)
    else:
        add_nodes(var.grad_fn)

 

    return reversed_graph

