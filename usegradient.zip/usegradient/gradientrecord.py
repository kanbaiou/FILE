import torch.nn.functional as F


def ttrace(grad_fn, depth=0):
    print("\t" * depth + str(depth) + ' : ' + str(type(grad_fn)) + str(type(grad_fn).__name__))
    if not hasattr(grad_fn, 'next_functions'):
        return
    #print("\t" * depth + str(len(grad_fn.next_functions)))
    for functions in grad_fn.next_functions:
        #print("\t" * depth + '>' + str(len(functions)))
        for function in functions:
            ttrace(function, depth+1)

def train(args, model, device, train_loader, optimizer, epoch):
    model.train()
    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()
        output = model(data)
        ttrace(output.mean().grad_fn)
        quit()
        loss = F.nll_loss(output, target)
        loss.backward()
        optimizer.step()
        if batch_idx % args.log_interval == 0:
            print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                epoch, batch_idx * len(data), len(train_loader.dataset),
                100. * batch_idx / len(train_loader), loss.item()))

def get_next_gradient_function(grad_fn):
      return(grad_fn.next_functions[0][0])